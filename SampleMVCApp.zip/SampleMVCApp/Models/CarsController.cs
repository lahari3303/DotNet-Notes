﻿using SampleMVCApp.DataComponents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SampleMVCApp.Models
{
    public class CarsController : Controller
    {
        // GET: Cars
        public ActionResult Index()
        {
            var repo = new CarInfoRepo();
            var model = repo.GetAllCars();
            return View(model);
        }
        public ActionResult Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                ViewBag.Message = "Car ID is not set, please visit Index page";
                return View();
            }
            var selectedId = int.Parse(id);
            var repo = new CarInfoRepo();
            var model = repo.FindCar(selectedId);
            if (model == null)
            {
                ViewBag.Message = "car Info is not available with us";
                return View();
            }
            return View(model);
        }
        [HttpPost]
        public ActionResult Edit(CarInfo updatedData)
        {
            var repo = new CarInfoRepo();
            repo.UpdateCar(updatedData);
            return RedirectToAction("Index");
        }

        public ActionResult AddCar() => View(new CarInfo());

        [HttpPost]
        public ActionResult AddCar(CarInfo posteddata)
        {
            var repo = new CarInfoRepo();
            repo.AddNewCar(posteddata);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string id)
        {
            var carId = int.Parse(id);
            var repo = new CarInfoRepo();
            repo.DeleteCar(carId);
            return RedirectToAction("Index");
        }
    }
}