﻿using SampleMVCApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SampleMVCApp.Controllers
{
    public class FirstExampleController : Controller
    {


        public string Helloworld() => "Hai from MVC";
        public double GetNumber(string v1, string v2)
        {
            var first = double.Parse(v1);
            var second = double.Parse(v2);
            return first + second;
        }
        // GET: FirstExample
        //public ActionResult Index()
        //{
        //    return View();
        //}

        public ViewResult Displayemployee()
        {
            Employee employee = new Employee()
            {
                EmployeeId = 12,
                EmployeeName = "Lahari",
                EmployeeEmail = "lahari!2@gmail.com",
                EmployeeSalary = 25000



            };
            return View(employee);
            



        }
    }
}